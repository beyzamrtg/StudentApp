package Models;


public class Ders {
    public String DersKodu;
    public String DersIsmi;
    public String DerDonem;
    public String OgretimGorevlisi;
    public  String DersGoster;
    public String DersArama;
}

